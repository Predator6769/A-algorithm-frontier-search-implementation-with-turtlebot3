# turtlebot3_gazebo
Formerly `ME597-Fall2024-tb3-gz`

### Launch house
`ros2 launch turtlebot3_gazebo turtlebot3_house_norviz.launch.py`

### Launch house & Red Ball (Lab 3 - Task 5)
`ros2 launch turtlebot3_gazebo task_5.launch.py`